/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraftforge.common.brewing;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;

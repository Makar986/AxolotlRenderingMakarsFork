/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.minecraftforge.fml.client.gui.widget;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.AbstractGui;
import net.minecraft.client.gui.widget.list.ExtendedList;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.ITextProperties;
import net.minecraft.util.text.LanguageMap;
import net.minecraft.util.text.StringTextComponent;
import net.minecraftforge.fml.client.gui.screen.ModListScreen;
import net.minecraftforge.versions.forge.ForgeVersion;
import net.minecraftforge.fml.MavenVersionStringHelper;
import net.minecraftforge.fml.VersionChecker;
import net.minecraftforge.fml.loading.moddiscovery.ModInfo;

import com.mojang.blaze3d.systems.RenderSystem;

public class ModListWidget extends ExtendedList<ModListWidget.ModEntry>
{
    private static String stripControlCodes(String value) { return net.minecraft.util.StringUtils.func_76338_a(value); }
    private static final ResourceLocation VERSION_CHECK_ICONS = new ResourceLocation(ForgeVersion.MOD_ID, "textures/gui/version_check_icons.png");
    private final int listWidth;

    private ModListScreen parent;

    public ModListWidget(ModListScreen parent, int listWidth, int top, int bottom)
    {
        super(parent.getMinecraftInstance(), listWidth, parent.field_230709_l_, top, bottom, parent.getFontRenderer().field_78288_b * 2 + 8);
        this.parent = parent;
        this.listWidth = listWidth;
        this.refreshList();
    }

    @Override
    protected int func_230952_d_()
    {
        return this.listWidth;
    }

    @Override
    public int func_230949_c_()
    {
        return this.listWidth;
    }

    public void refreshList() {
        this.func_230963_j_();
        parent.buildModList(this::func_230513_b_, mod->new ModEntry(mod, this.parent));
    }

    @Override
    protected void func_230433_a_(MatrixStack mStack)
    {
        this.parent.func_230446_a_(mStack);
    }

    public class ModEntry extends ExtendedList.AbstractListEntry<ModEntry> {
        private final ModInfo modInfo;
        private final ModListScreen parent;

        ModEntry(ModInfo info, ModListScreen parent) {
            this.modInfo = info;
            this.parent = parent;
        }

        @Override
        public void func_230432_a_(MatrixStack mStack, int entryIdx, int top, int left, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean p_194999_5_, float partialTicks)
        {
            ITextComponent name = new StringTextComponent(stripControlCodes(modInfo.getDisplayName()));
            ITextComponent version = new StringTextComponent(stripControlCodes(MavenVersionStringHelper.artifactVersionToString(modInfo.getVersion())));
            VersionChecker.CheckResult vercheck = VersionChecker.getResult(modInfo);
            FontRenderer font = this.parent.getFontRenderer();
            font.func_238422_b_(mStack, LanguageMap.func_74808_a().func_241870_a(ITextProperties.func_240655_a_(font.func_238417_a_(name,    listWidth))), left + 3, top + 2, 0xFFFFFF);
            font.func_238422_b_(mStack, LanguageMap.func_74808_a().func_241870_a(ITextProperties.func_240655_a_(font.func_238417_a_(version, listWidth))), left + 3, top + 2 + font.field_78288_b, 0xCCCCCC);
            if (vercheck.status.shouldDraw())
            {
                //TODO: Consider adding more icons for visualization
                Minecraft.func_71410_x().func_110434_K().func_110577_a(VERSION_CHECK_ICONS);
                RenderSystem.color4f(1, 1, 1, 1);
                RenderSystem.pushMatrix();
                AbstractGui.func_238463_a_(mStack, getLeft() + field_230670_d_ - 12, top + entryHeight / 4, vercheck.status.getSheetOffset() * 8, (vercheck.status.isAnimated() && ((System.currentTimeMillis() / 800 & 1)) == 1) ? 8 : 0, 8, 8, 64, 16);
                RenderSystem.popMatrix();
            }
        }

        @Override
        public boolean func_231044_a_(double p_mouseClicked_1_, double p_mouseClicked_3_, int p_mouseClicked_5_)
        {
            parent.setSelected(this);
            ModListWidget.this.func_241215_a_(this);
            return false;
        }

        public ModInfo getInfo()
        {
            return modInfo;
        }
    }
}

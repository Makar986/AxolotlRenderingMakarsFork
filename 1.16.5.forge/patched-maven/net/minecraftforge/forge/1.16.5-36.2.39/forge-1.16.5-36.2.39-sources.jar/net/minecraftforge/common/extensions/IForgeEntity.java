/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.minecraftforge.common.extensions;

import java.util.Collection;
import java.util.Collections;
import javax.annotation.Nullable;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.LeashKnotEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Pose;
import net.minecraft.entity.EntityClassification;
import net.minecraft.entity.EntitySize;
import net.minecraft.entity.item.ArmorStandEntity;
import net.minecraft.entity.item.BoatEntity;
import net.minecraft.entity.item.EnderCrystalEntity;
import net.minecraft.entity.item.ItemEntity;
import net.minecraft.entity.item.ItemFrameEntity;
import net.minecraft.entity.item.minecart.AbstractMinecartEntity;
import net.minecraft.entity.item.PaintingEntity;
import net.minecraft.item.Items;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;
import net.minecraftforge.entity.PartEntity;
import net.minecraftforge.event.ForgeEventFactory;
import net.minecraftforge.event.entity.EntityEvent;

public interface IForgeEntity extends ICapabilitySerializable<CompoundNBT>
{
    default Entity getEntity() { return (Entity) this; }

    default void deserializeNBT(CompoundNBT nbt)
    {
        getEntity().func_70020_e(nbt);
    }

    default CompoundNBT serializeNBT()
    {
        CompoundNBT ret = new CompoundNBT();
        String id = getEntity().func_70022_Q();
        if (id != null)
        {
            ret.func_74778_a("id", getEntity().func_70022_Q());
        }
        return getEntity().func_189511_e(ret);
    }

    boolean canUpdate();
    void canUpdate(boolean value);

    @Nullable
    Collection<ItemEntity> captureDrops();
    Collection<ItemEntity> captureDrops(@Nullable Collection<ItemEntity> captureDrops);


    /**
     * Returns a NBTTagCompound that can be used to store custom data for this entity.
     * It will be written, and read from disc, so it persists over world saves.
     * @return A NBTTagCompound
     */
    CompoundNBT getPersistentData();

    /**
     * Used in model rendering to determine if the entity riding this entity should be in the 'sitting' position.
     * @return false to prevent an entity that is mounted to this entity from displaying the 'sitting' animation.
     */
    default boolean shouldRiderSit()
    {
        return true;
    }

    /**
     * Called when a user uses the creative pick block button on this entity.
     *
     * @param target The full target the player is looking at
     * @return A ItemStack to add to the player's inventory, empty ItemStack if nothing should be added.
     */
    default ItemStack getPickedResult(RayTraceResult target)
    {
        if (this instanceof PaintingEntity)
            return new ItemStack(Items.field_151159_an);
        else if (this instanceof LeashKnotEntity)
            return new ItemStack(Items.field_151058_ca);
        else if (this instanceof ItemFrameEntity)
        {
            ItemStack held = ((ItemFrameEntity)this).func_82335_i();
            if (held.func_190926_b())
                return new ItemStack(Items.field_151160_bD);
            else
                return held.func_77946_l();
        }
        else if (this instanceof AbstractMinecartEntity)
            return ((AbstractMinecartEntity)this).getCartItem();
        else if (this instanceof BoatEntity)
            return new ItemStack(((BoatEntity)this).func_184455_j());
        else if (this instanceof ArmorStandEntity)
            return new ItemStack(Items.field_179565_cj);
        else if (this instanceof EnderCrystalEntity)
            return new ItemStack(Items.field_185158_cP);
        else
        {
            SpawnEggItem egg = ForgeSpawnEggItem.fromEntityType(getEntity().func_200600_R());
            if (egg != null) return new ItemStack(egg);
        }
        return ItemStack.field_190927_a;
    }

    /**
     * If a rider of this entity can interact with this entity. Should return true on the
     * ridden entity if so.
     *
     * @return if the entity can be interacted with from a rider
     */
    default boolean canRiderInteract()
    {
        return false;
    }

    /**
     * Checks if this entity can continue to be ridden while it is underwater.
     *
     * @param rider The entity that is riding this entity
     * @return {@code true} if the entity can continue to ride underwater. {@code false} otherwise.
     */
    default boolean canBeRiddenInWater(Entity rider)
    {
        return getEntity().func_205710_ba();
    }

    /**
     * Checks if this {@link Entity} can trample a {@link Block}.
     *
     * @param pos The block pos
     * @param fallDistance The fall distance
     * @return {@code true} if this entity can trample, {@code false} otherwise
     */
    boolean canTrample(BlockState state, BlockPos pos, float fallDistance);

    /**
     * Returns The classification of this entity
     * @param forSpawnCount If this is being invoked to check spawn count caps.
     * @return If the creature is of the type provided
     */
    default EntityClassification getClassification(boolean forSpawnCount)
    {
        return getEntity().func_200600_R().func_220339_d();
    }

    /**
     * Gets whether this entity has been added to a world (for tracking). Specifically
     * between the times when an entity is added to a world and the entity being removed
     * from the world's tracked lists. See {@link World#onEntityAdded(Entity)} and
     * {@link World#onEntityRemoved(Entity)}.
     *
     * @return True if this entity is being tracked by a world
     */
    boolean isAddedToWorld();

    /**
     * Called after the entity has been added to the world's
     * ticking list. Can be overriden, but needs to call super
     * to prevent MC-136995.
     */
    void onAddedToWorld();

    /**
     * Called after the entity has been removed to the world's
     * ticking list. Can be overriden, but needs to call super
     * to prevent MC-136995.
     */
    void onRemovedFromWorld();

    /**
     * Revives an entity that has been removed from a world.
     * Used as replacement for entity.removed = true. Having it as a function allows
     * the entity to react to being revived.
     */
    void revive();


    /**
     * This is used to specify that your entity has multiple individual parts, such as the Vanilla Ender Dragon.
     *
     * See {@link net.minecraft.entity.boss.dragon.EnderDragonEntity} for an example implementation.
     * @return true if this is a multipart entity.
     */
    default boolean isMultipartEntity()
    {
        return false;
    }

    /**
     * Gets the individual sub parts that make up this entity.
     *
     * The entities returned by this method are NOT saved to the world in nay way, they exist as an extension
     * of their host entity. The child entity does not track its server-side(or client-side) counterpart, and
     * the host entity is responsible for moving and managing these children.
     *
     * Only used if {@link #isMultipartEntity()} returns true.
     *
     * See {@link net.minecraft.entity.boss.dragon.EnderDragonEntity} for an example implementation.
     * @return The child parts of this entity. The value to be returned here should be cached.
     */
    @Nullable
    default PartEntity<?>[] getParts()
    {
        return null;
    }

    default EntitySize getDimensionsForge(Pose pose)
    {
        EntitySize size = getEntity().func_213305_a(pose);
        float eyeHeight = getEntity().getEyeHeightAccess(pose, size);
        EntityEvent.Size e = ForgeEventFactory.getEntitySizeForge(getEntity(), pose, size, eyeHeight);
        return e.getNewSize();
    }

    default float getEyeHeightForge(Pose pose, EntitySize size)
    {
        float eyeHeight = getEntity().getEyeHeightAccess(pose, size);
        EntityEvent.Size e = ForgeEventFactory.getEntitySizeForge(getEntity(), pose, size, eyeHeight);
        return e.getNewEyeHeight();
    }
}
